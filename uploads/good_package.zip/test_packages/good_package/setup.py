from setuptools import setup

setup(
    name="good_package",
    version="0.0.0",
    packages=[],
)
